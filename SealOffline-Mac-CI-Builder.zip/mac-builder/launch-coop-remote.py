"""Create a temporary guest-only tunnel when the host explicitly launches this tool."""
from contextlib import ExitStack
from functools import partial
from pathlib import Path
import queue
import os
import socket
import ipaddress
import re
import runpy
import secrets
import shutil
import subprocess
import threading
import sys
import webbrowser

coop = runpy.run_path(str(Path(__file__).with_name("launch-coop.py")))
ROOT = coop["ROOT"]
URL = re.compile(r"https://([a-z0-9-]+\.trycloudflare\.com)(?![a-z0-9.-])")


def open_tunnel(stack, executable, port):
    process = subprocess.Popen([executable, "tunnel", "--url", f"http://127.0.0.1:{port}"],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, encoding="utf-8", errors="replace")

    def stop():
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()

    stack.callback(stop)
    result = queue.Queue()

    def read():
        for line in process.stdout:
            match = URL.search(line)
            if match:
                result.put(match.group(1))
        result.put(None)

    threading.Thread(target=read, daemon=True).start()
    try:
        hostname = result.get(timeout=60)
    except queue.Empty:
        hostname = None
    if not hostname:
        raise RuntimeError("無法建立臨時網址，請確認 cloudflared 能連上網路後重新開房。")
    return hostname, process


def main(menu=False,lan=False):
    if sys.platform == "darwin":
        exe = shutil.which("cloudflared") or shutil.which(
            "cloudflared", path="/opt/homebrew/bin:/usr/local/bin"
        )
        data = Path.home() / "Library" / "Application Support" / "SealOfflineStory" / "coop"
        if not lan and not exe:
            raise RuntimeError("異地開房需要 Mac 版 cloudflared。安裝後請重新開房。")
    else:
        bundled = ROOT / "cloudflared.exe"
        exe = str(bundled) if bundled.is_file() else shutil.which("cloudflared")
        data = ROOT / "build" / "coop-remote"
        if not lan and not exe:
            raise RuntimeError("房主需要 Cloudflare 的 cloudflared.exe。請放到 Play-Coop-Remote.cmd 旁邊，再重新開房。")
    game = Path(os.environ.get("SEAL_GAME_ROOT", str(ROOT / "game")))
    data.mkdir(parents=True, exist_ok=True)
    with ExitStack() as stack:
        handler = partial(coop["Handler"], directory=str(game))
        def listener(port,address="127.0.0.1"):
            server = coop["CoopServer"]((address, port), handler)
            stack.callback(server.server_close)
            return server
        address="127.0.0.1"
        if lan:
            candidates = []
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as route:
                    route.connect(("192.0.2.1", 9))
                    candidates.append(route.getsockname()[0])
            except OSError:
                pass
            try:
                candidates.extend(r[4][0] for r in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET))
            except OSError:
                pass
            address = next((str(ip) for ip in map(ipaddress.ip_address, candidates)
                            if ip.is_private and not ip.is_loopback and not ip.is_link_local), None)
            if not address: raise RuntimeError("找不到區域網路位址，請先連上 Wi-Fi 或有線網路。")
        host, guest = listener(0 if menu else 8778), listener(0,address)
        room = coop["Room"](data / "rewards.sqlite3")
        stack.callback(room.db.close)
        room.host, room.invite, room.guest = secrets.token_urlsafe(24), secrets.token_urlsafe(24), None
        with room.db:
            room.db.execute("UPDATE seats SET host=?,invite=?,guest=NULL WHERE id=1",(room.host,room.invite))
        host.room = guest.room = room
        host.desktop_launcher = menu
        guest.guest_only = True
        process=None
        if lan:
            origin=f"http://{address}:{guest.server_port}"
        else:
            hostname, process = open_tunnel(stack, str(exe), guest.server_port)
            guest.public_host = hostname
            origin=f"https://{hostname}"
        host.invite_url = guest.invite_url = f"{origin}/coop.html#{room.invite}"
        for server in (host, guest):
            threading.Thread(target=server.serve_forever, daemon=True).start()
            stack.callback(server.shutdown)
        local = f"http://127.0.0.1:{host.server_port}/coop.html#{room.host}"
        closed = threading.Event()
        if menu:
            print(local, flush=True)
            def watch_launcher():
                sys.stdin.buffer.read(1)
                closed.set()
            threading.Thread(target=watch_launcher, daemon=True).start()
        else:
            print("房主入口：", local, "\n朋友邀請：", host.invite_url, "\n按 Ctrl+C 關房。", flush=True)
            webbrowser.open(local)
        while process is None or process.poll() is None:
            if closed.wait(.5):
                return
        raise RuntimeError("臨時通道已關閉。請重新開房並分享新的邀請連結。")


if __name__ == "__main__":
    try:
        main("--menu" in sys.argv[1:],"--lan" in sys.argv[1:])
    except KeyboardInterrupt:
        pass
    except (RuntimeError, OSError) as error:
        raise SystemExit(str(error))
