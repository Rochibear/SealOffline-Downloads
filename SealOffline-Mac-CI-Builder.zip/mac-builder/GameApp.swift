import AppKit

@main
@MainActor
final class GameApp: NSObject, NSApplicationDelegate {
    private let game = GameWindow()

    static func main() {
        let application = NSApplication.shared
        let delegate = GameApp()
        application.delegate = delegate
        application.setActivationPolicy(.regular)
        application.run()
        withExtendedLifetime(delegate) {}
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        let resources = Bundle.main.resourceURL!
        game.start(game: resources.appendingPathComponent("game"),
                   script: resources.appendingPathComponent("tools/launch-story.py"), coop: true) { [weak self] message, _ in
            if self?.game.isRunning == true { return }
            if !message.isEmpty {
                NSApp.activate(ignoringOtherApps: true)
                let alert = NSAlert()
                alert.messageText = message
                alert.runModal()
            }
            NSApp.terminate(nil)
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        game.stop(notify: false)
    }
}
