#!/bin/bash
set -eu
cd "$(dirname "$0")"
out="$PWD/SealOffline-Origins.dmg"
version="${1:-}"
if [[ -n "$version" && ! "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo '版本格式須為三段數字，例如 0.2.2。'
  exit 1
fi
if [[ -e "$out" ]]; then
  echo '已有同名 DMG，請先將舊檔移到別處。'
  exit 1
fi
stage="$(mktemp -d)"
trap 'rm -rf "$stage"' EXIT
app="$stage/SealOffline.app"
contents="$app/Contents"
resources="$contents/Resources"
mkdir -p "$contents/MacOS" "$resources/tools"
xcrun swiftc -module-cache-path "$stage/swift-cache" -parse-as-library -O -target arm64-apple-macos12.0 GameApp.swift GameWindow.swift -o "$contents/MacOS/SealOffline"
rm -rf "$stage/swift-cache"
/usr/bin/ditto "${SEAL_GAME_SOURCE:-game}" "$resources/game"
tools=tools
if [[ ! -f "$tools/launch-story.py" ]]; then tools=.; fi
cp "$tools/launch-story.py" "$tools/launch-coop.py" "$tools/launch-coop-remote.py" "$resources/tools/"
cp SealOffline.icns "$resources/"
cat > "$contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<plist version="1.0"><dict>
<key>CFBundleIconFile</key><string>SealOffline.icns</string>
<key>CFBundleExecutable</key><string>SealOffline</string>
<key>CFBundleIdentifier</key><string>tw.sealfans.origins.game</string>
<key>CFBundleName</key><string>SealOffline</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
</dict></plist>
PLIST
if [[ -n "$version" ]]; then
  /usr/libexec/PlistBuddy -c "Add :CFBundleShortVersionString string $version" "$contents/Info.plist"
fi
/usr/bin/codesign --force --sign - "$app"
/usr/bin/codesign --verify --strict "$app"
ln -s /Applications "$stage/Applications"
/usr/bin/hdiutil create -volname 'SealOffline Origins' -srcfolder "$stage" -format UDZO "$out"
/usr/bin/hdiutil verify "$out"
echo "製作完成 $out"
