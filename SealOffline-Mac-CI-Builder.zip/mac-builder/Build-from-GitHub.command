#!/bin/bash
set -eu
root="$(cd "$(dirname "$0")" && pwd -P)"
if ! command -v python3 >/dev/null || ! python3 -c 'import sys; sys.exit(sys.version_info < (3, 8))'; then
  echo '需要 Python 3.8 以上才能製作 DMG。'
  exit 1
fi
if [[ -z "${SSL_CERT_FILE:-}" && -r /etc/ssl/cert.pem ]]; then
  export SSL_CERT_FILE=/etc/ssl/cert.pem
fi
if [[ "$#" -eq 0 ]]; then
  default_version="$(python3 "$root/build-from-github.py" --latest-version)"
  printf '輸入 Windows 發行版本 [%s]：' "$default_version"
  IFS= read -r version
  set -- "${version:-$default_version}"
fi
exec python3 "$root/build-from-github.py" --output-dir "$root" "$@"
