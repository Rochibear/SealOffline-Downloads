"""Build a macOS release from the common game files in a published Windows ZIP."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.request import Request, urlopen
from zipfile import BadZipFile, ZipFile


REPO = "Rochibear/SealOffline-Downloads"
SCRIPT_DIR = Path(__file__).resolve().parent


def open_url(url):
    return urlopen(Request(url, headers={"User-Agent": "SealOffline-Mac-Builder"}), timeout=60)


def windows_asset(release, version, name):
    tag = f"v{version}"
    if release["tag_name"] != tag or release["draft"] or release["prerelease"]:
        return None
    url = f"https://github.com/{REPO}/releases/download/{tag}/{name}.zip"
    for asset in release["assets"]:
        if (asset["name"], asset["state"], asset["browser_download_url"]) != (f"{name}.zip", "uploaded", url):
            continue
        digest = asset.get("digest") or ""
        if re.fullmatch(r"sha256:[a-f0-9]{64}", digest) and asset["size"] > 0:
            return url, asset["size"], digest[7:]
    return None


def latest_windows_version():
    versions = []
    page = 1
    while True:
        with open_url(f"https://api.github.com/repos/{REPO}/releases?per_page=100&page={page}") as response:
            releases = json.load(response)
        for release in releases:
            tag = release["tag_name"]
            if not re.fullmatch(r"v[0-9]+\.[0-9]+\.[0-9]+", tag):
                continue
            version = tag[1:]
            if windows_asset(release, version, f"SealOffline-Origins-Windows-x64-V{version}"):
                versions.append(version)
        if len(releases) < 100:
            break
        page += 1
    if not versions:
        raise ValueError("找不到附有可驗證完整 ZIP 的正式 Windows 發行版。")
    return max(versions, key=lambda version: tuple(map(int, version.split("."))))


def windows_release(version, name):
    with open_url(f"https://api.github.com/repos/{REPO}/releases/tags/v{version}") as response:
        release = json.load(response)
    asset = windows_asset(release, version, name)
    if asset is None:
        raise ValueError(f"找不到正式且可驗證的 Windows 遊戲包：{name}.zip")
    return asset


def extract_game(archive_path, package_name, dest):
    prefix = f"{package_name}/game/"
    count = 0
    with ZipFile(archive_path) as archive:
        for member in archive.infolist():
            if member.is_dir() or not member.filename.startswith(prefix):
                continue
            name = member.filename[len(prefix):]
            parts = PurePosixPath(name).parts
            if not parts or name.startswith("/") or ".." in parts or "\\" in name:
                raise ValueError(f"無效的遊戲檔路徑：{member.filename}")
            target = dest.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, target.open("xb") as output:
                shutil.copyfileobj(source, output)
            count += 1
    for filename in ("east-island-native-preview.html", "east-island-native-preview.mjs", "story-launch.mjs"):
        if not (dest / filename).is_file():
            raise ValueError(f"遊戲包缺少入口：{filename}")
    if "allowChapterPreview=false" not in (dest / "story-launch.mjs").read_text(encoding="utf-8"):
        raise ValueError("遊戲包未關閉章節試玩")
    return count


def verify_archive(path, expected_size, expected_hash):
    if path.stat().st_size != expected_size:
        raise ValueError("ZIP 大小與 GitHub 發行資訊不符")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != expected_hash:
        raise ValueError("ZIP 的 SHA-256 與 GitHub 發行資訊不符")


def download_archive(url, path, expected_size):
    downloaded = 0
    next_progress = 10
    with open_url(url) as response, path.open("xb") as stream:
        for chunk in iter(lambda: response.read(1024 * 1024), b""):
            downloaded += len(chunk)
            if downloaded > expected_size:
                raise ValueError("下載大小超過 GitHub 發行資訊")
            stream.write(chunk)
            percent = downloaded * 100 // expected_size
            if percent >= next_progress:
                print(f"已下載 {percent}%", flush=True)
                next_progress = percent + 10


def save_image(source, output):
    # The final location may be a removable drive that cannot create hard links.
    with source.open("rb") as image:
        final = output.open("xb")
        try:
            with final:
                shutil.copyfileobj(image, final)
        except BaseException:
            output.unlink()
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("version", nargs="?", help="指定 Windows 發行版本，例如 0.2.2")
    parser.add_argument("--latest-version", action="store_true", help="查詢最新正式 Windows 版本，不製作 DMG")
    parser.add_argument("--archive", type=Path, help="指定已下載的 Windows ZIP，仍會核對 GitHub 上的大小與 SHA-256")
    parser.add_argument("--output-dir", type=Path, help="指定 DMG 輸出資料夾")
    parser.add_argument("--verify-only", action="store_true", help="只驗證並解出共用遊戲檔")
    args = parser.parse_args()
    if args.latest_version:
        print(latest_windows_version())
        return
    version = args.version or latest_windows_version()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
        parser.error("版本格式應為 0.2.1")
    if not args.verify_only and sys.platform != "darwin":
        parser.error("製作 DMG 必須在 Mac 執行")
    bundled_launcher = SCRIPT_DIR / "launch-story.py"
    output_dir = args.output_dir or (SCRIPT_DIR if bundled_launcher.is_file() else Path.cwd())
    output = output_dir / f"SealOffline-Origins-Mac-V{version}.dmg"
    if not args.verify_only and output.exists():
        parser.error(f"已經有同名 DMG：{output}")

    package_name = f"SealOffline-Origins-Windows-x64-V{version}"
    print(f"查詢 GitHub 發行版 V{version}…", flush=True)
    url, size, digest = windows_release(version, package_name)
    with tempfile.TemporaryDirectory(prefix=".sealoffline-build-") as temporary:
        stage = Path(temporary)
        archive_path = args.archive
        if archive_path is None:
            archive_path = stage / f"{package_name}.zip"
            print(f"下載 V{version} 遊戲內容（約 {size // 1_000_000} MB）…", flush=True)
            download_archive(url, archive_path, size)
        print("核對 SHA-256 並解出遊戲檔…", flush=True)
        verify_archive(archive_path, size, digest)
        count = extract_game(archive_path, package_name, stage / "game")
        print(f"SHA-256 已驗證，共 {count} 個遊戲檔。", flush=True)
        if args.verify_only:
            return
        for filename in ("Make-DMG.command", "GameApp.swift", "GameWindow.swift", "SealOffline.icns"):
            script = (SCRIPT_DIR / filename).read_bytes().replace(b"\r\n", b"\n")
            (stage / filename).write_bytes(script)
        (stage / "tools").mkdir()
        tools_dir = SCRIPT_DIR if bundled_launcher.is_file() else SCRIPT_DIR.parent
        for filename in ("launch-story.py", "launch-coop.py", "launch-coop-remote.py"):
            shutil.copyfile(tools_dir / filename, stage / "tools" / filename)
        print("執行 macOS 打包與 DMG 驗證…", flush=True)
        subprocess.run(["/bin/bash", str(stage / "Make-DMG.command"), version], check=True)
        save_image(stage / "SealOffline-Origins.dmg", output)
        print(f"製作完成：{output}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, BadZipFile, subprocess.CalledProcessError) as exc:
        sys.exit(f"製作失敗：{exc}")
