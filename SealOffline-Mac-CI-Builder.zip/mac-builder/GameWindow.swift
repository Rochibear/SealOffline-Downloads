import AppKit
import WebKit

@MainActor
final class GameWindow: NSObject, NSWindowDelegate, WKNavigationDelegate, WKUIDelegate {
    private var server: Process?
    private var window: NSWindow?
    private var webView: WKWebView?
    private var loading: Task<Void, Never>?
    private var report: ((String, Bool) -> Void)?
    private var startupOrigin: URL?

    var isRunning: Bool { server != nil }

    func start(game: URL, script: URL, coop: Bool, report: @escaping (String, Bool) -> Void) {
        if isRunning {
            window?.makeKeyAndOrderFront(nil)
            return
        }
        self.report = report
        let task = Process()
        let events = Pipe()
        task.standardInput = Pipe()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/env")
        task.arguments = ["python3", "-B", script.path, "--game-root", game.path, "--game-window"]
            + (coop ? ["--desktop-coop"] : [])
        var environment = ProcessInfo.processInfo.environment
        environment["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + (environment["PATH"] ?? "/usr/bin:/bin")
        task.environment = environment
        task.standardOutput = events
        task.terminationHandler = { [weak self] stopped in
            Task { @MainActor in
                guard let self = self, self.server === stopped else { return }
                self.server = nil
                self.closeWindow()
                if stopped.terminationStatus == 0 {
                    self.report?("", false)
                } else if stopped.terminationStatus == 98 {
                    self.report?("本機遊戲連接埠已被使用。請先結束舊登入器的遊戲服務，再啟動新版。", false)
                } else {
                    self.report?("無法啟動本機遊戲服務。請確認 Python 3 已安裝，並關閉其他執行中的遊戲。", false)
                }
            }
        }
        do {
            try task.run()
        } catch {
            report(error.localizedDescription, false)
            return
        }
        server = task
        report("正在啟動本機遊戲服務…", true)
        loading = Task { [weak self] in
            do {
                for try await line in events.fileHandleForReading.bytes.lines {
                    guard let self = self, self.server === task else { return }
                    let prefix = "SEAL_GAME_URL "
                    if line.hasPrefix(prefix), self.window == nil,
                       let url = URL(string: String(line.dropFirst(prefix.count))), self.isLocal(url) {
                        self.show(url)
                    } else if line == "SEAL_MODULE" {
                        self.report?("遊戲視窗已開啟。", false)
                    }
                }
            } catch {
                guard let self = self, self.server === task else { return }
                self.fail("無法讀取遊戲服務的啟動狀態。")
            }
        }
    }

    func stop(notify: Bool = true) {
        let task = server
        server = nil
        closeWindow()
        if let task = task, task.isRunning { task.terminate() }
        if notify { report?("", false) }
    }

    private func closeWindow() {
        loading?.cancel()
        loading = nil
        let closing = window
        window = nil
        webView?.stopLoading()
        webView = nil
        startupOrigin = nil
        closing?.delegate = nil
        closing?.close()
    }

    private func fail(_ message: String) {
        stop()
        report?(message, false)
    }

    private func show(_ url: URL) {
        startupOrigin = url
        let configuration = WKWebViewConfiguration()
        configuration.mediaTypesRequiringUserActionForPlayback = []
        if #available(macOS 12.3, *) {
            configuration.preferences.isElementFullscreenEnabled = true
        }
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = self
        view.uiDelegate = self
        view.allowsBackForwardNavigationGestures = false
        let frame = NSScreen.main?.visibleFrame.size ?? NSSize(width: 1200, height: 780)
        let size = NSSize(width: min(frame.width, 1280), height: min(frame.height - 28, 820))
        let window = NSWindow(contentRect: NSRect(origin: .zero, size: size),
                              styleMask: [.titled, .closable, .miniaturizable, .resizable],
                              backing: .buffered, defer: false)
        window.title = "嚕啦族：起源"
        window.isReleasedWhenClosed = false
        window.delegate = self
        window.contentView = view
        window.center()
        self.window = window
        webView = view
        window.makeKeyAndOrderFront(nil)
        window.makeFirstResponder(view)
        NSApp.activate(ignoringOtherApps: true)
        report?("正在載入遊戲視窗…", true)
        view.load(URLRequest(url: url))
    }

    func windowWillClose(_ notification: Notification) {
        // The existing close is already in progress.
        window = nil
        stop()
    }

    private func isLocal(_ url: URL) -> Bool {
        url.scheme == "http" && url.host == "127.0.0.1" && url.port != nil
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        if isLocal(url) {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
            if action.navigationType == .linkActivated && url.scheme == "https" {
                NSWorkspace.shared.open(url)
            }
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url, isLocal(url) { webView.load(action.request) }
        return nil
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if webView.url == nil && (error as NSError).code != NSURLErrorCancelled {
            fail("無法載入遊戲視窗。\(error.localizedDescription)")
        }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if let url = startupOrigin { webView.load(URLRequest(url: url)) }
    }
}
