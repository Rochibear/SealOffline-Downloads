"""Private, two-seat story playtest. The host browser owns the simulation."""
import argparse
import json
import math
import secrets
import socket
import sqlite3
import threading
import time
import webbrowser
import os
from urllib.request import Request, urlopen
from functools import partial
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = ("return", "limeLeona", "raygant", "sewer")


class Room:
    def __init__(self, path):
        self.lock = threading.Lock()
        self.db = sqlite3.connect(str(path), check_same_thread=False)
        with self.db:
            self.db.execute("CREATE TABLE IF NOT EXISTS rewards (role INTEGER, boss TEXT, items TEXT, claimed INTEGER DEFAULT 0, PRIMARY KEY(role,boss))")
        with self.db:
            self.db.execute("CREATE TABLE IF NOT EXISTS seats (id INTEGER PRIMARY KEY, host TEXT, invite TEXT, guest TEXT)")
            self.db.execute("INSERT OR IGNORE INTO seats VALUES(1,?,?,NULL)",(secrets.token_urlsafe(24),secrets.token_urlsafe(24)))
        self.host,self.invite,self.guest=self.db.execute("SELECT host,invite,guest FROM seats WHERE id=1").fetchone()
        self.run = ""
        self.scenario = ""
        self.state = None
        self.input = {}
        self.seen = 0
        self.host_seen = 0
        self.joined_run = None
        self.pair_a = ""
        self.a_until = 0
        self.scans = {}
        self.devices = {}

    def pairing(self, op, data, scanner):
        now = time.monotonic()
        with self.lock:
            self.devices = {k:v for k,v in self.devices.items() if v["until"] > now}
            self.scans = {k:v for k,v in self.scans.items() if v > now}
            if op == "device":
                if len(self.devices) >= 24:
                    raise ValueError("too many pending screens")
                code, secret = secrets.token_urlsafe(14), secrets.token_urlsafe(24)
                self.devices[code] = {"secret":secret,"until":now+180,"approved":False}
                return {"code":code,"secret":secret}, None
            if op == "scan-a":
                if not self.pair_a or now >= self.a_until or not secrets.compare_digest(data.get("code",""),self.pair_a):
                    raise ValueError("expired room code")
                if len(self.scans)>=24:
                    raise ValueError("too many pending scans")
                session=secrets.token_urlsafe(24)
                self.scans[session]=min(self.a_until,now+180)
                return {"step":"B"}, ("scan",session)
            device=self.devices.get(data.get("code",""))
            if not device:
                raise ValueError("expired device code")
            if op == "scan-b":
                if scanner not in self.scans or self.guest or device["approved"] or any(d["approved"] for d in self.devices.values()):
                    raise ValueError("scan A first or seat occupied")
                del self.scans[scanner]
                device["approved"]=True
                self.a_until=0
                return {"paired":True}, None
            if not secrets.compare_digest(device["secret"],data.get("secret","")):
                raise ValueError("invalid device")
            if not device["approved"]:
                return {"paired":False}, None
            if not self.guest:
                self.guest=secrets.token_urlsafe(24)
                with self.db:
                    self.db.execute("UPDATE seats SET guest=? WHERE id=1",(self.guest,))
            return {"paired":True}, ("coop",self.guest)

    def action(self, role, op, data):
        now = time.monotonic()
        with self.lock:
            if op == "start" and role == 1 and data.get("scenario") in SCENARIOS:
                self.scenario = data["scenario"]
                self.run = secrets.token_hex(8)
                self.state, self.input, self.joined_run = None, {}, None
            elif op == "tick":
                if data.get("run") != self.run or not self.run:
                    return {"stale": True}
                if role == 1:
                    self.host_seen = now
                    self.state = data["world"]
                    return {"input": self.input if now-self.seen < .8 else {}, "guest": now-self.seen < 5}
                controls = data.get("input", {})
                self.input = {k:controls.get(k,0) for k in ("x","z","yaw","attack","heavy","dodge") if isinstance(controls.get(k,0),(int,float)) and math.isfinite(controls.get(k,0))}
                self.input["ready"]=controls.get("ready") is True
                self.seen = now
                if controls.get("ready"):
                    self.joined_run = self.run
                return {"world": self.state, "host": now-self.host_seen < 5}
            elif op == "win" and role == 1 and self.run and data.get("run") == self.run and self.scenario in ("limeLeona","raygant"):
                with self.db:
                    for seat in (1,2):
                        if seat == 1 or self.joined_run == self.run:
                            items = data["items"][str(seat)]
                            if not isinstance(items,list) or not 1 <= len(items) <= 2:
                                raise ValueError("invalid reward")
                            self.db.execute("INSERT OR IGNORE INTO rewards(role,boss,items) VALUES(?,?,?)",(seat,self.scenario,json.dumps(items,ensure_ascii=False)))
            elif op == "claim":
                with self.db:
                    self.db.execute("UPDATE rewards SET claimed=1 WHERE role=? AND boss=? AND claimed=0",(role,data.get("boss")))
            elif op != "lobby":
                raise ValueError("invalid action")
            rewards=[{"boss":boss,"items":json.loads(items),"claimed":bool(claimed)} for boss,items,claimed in self.db.execute("SELECT boss,items,claimed FROM rewards WHERE role=?",(role,))]
            return {"role":role,"run":self.run,"scenario":self.scenario,"guest":self.guest is not None,"rewards":rewards}


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, ".mjs":"text/javascript"}
    def log_message(self, fmt, *args):
        pass

    def role(self):
        cookies=SimpleCookie()
        cookies.load(self.headers.get("Cookie",""))
        token=cookies.get("coop")
        if not getattr(self.server,"guest_only",False) and token and secrets.compare_digest(token.value,self.server.room.host):
            return 1
        if token and self.server.room.guest and secrets.compare_digest(token.value,self.server.room.guest):
            return 2
        return 0

    def reply(self, code, value, cookie=None):
        body=json.dumps(value,ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(body)))
        if cookie:
            name,token=cookie if isinstance(cookie,tuple) else ("coop",cookie)
            self.send_header("Set-Cookie",name+"="+token+"; HttpOnly; SameSite=Lax; Path=/"+("; Max-Age=180" if name=="scan" else "; Max-Age=2592000"))
        self.end_headers()
        self.wfile.write(body)

    def list_directory(self, path):
        self.send_error(403)

    def do_GET(self):
        path=urlsplit(self.path).path
        if path not in ("/coop.html","/coop-lobby.mjs","/vendor/qr-code.mjs") and not self.role():
            self.send_error(403)
            return
        super().do_GET()

    def do_HEAD(self):
        if not self.role():
            self.send_error(403)
            return
        super().do_HEAD()

    def do_POST(self):
        if self.headers.get_content_type() != "application/json" or urlsplit(self.headers.get("Origin","")).netloc not in ("",getattr(self.server,"public_host",None) or self.headers.get("Host")):
            return self.reply(403,{})
        try:
            size=int(self.headers.get("Content-Length",0))
            if not 0<size<=160000:
                return self.reply(413,{})
            data=json.loads(self.rfile.read(size))
            op=self.path[len("/coop/"):] if self.path.startswith("/coop/") else ""
            room=self.server.room
            if op in ("device","scan-a","scan-b","poll-device"):
                return self.reply(410,{"error":"請改用房主提供的朋友邀請連結。"})
            if op=="enter":
                key=data.get("key","")
                with room.lock:
                    if not getattr(self.server,"guest_only",False) and key and secrets.compare_digest(key,room.host) and self.client_address[0]=="127.0.0.1":
                        return self.reply(200,{"role":1},room.host)
                    if key and secrets.compare_digest(key,room.invite) and room.guest is None and not any(d["approved"] and d["until"]>time.monotonic() for d in room.devices.values()):
                        room.guest=secrets.token_urlsafe(24)
                        with room.db:
                            room.db.execute("UPDATE seats SET guest=? WHERE id=1",(room.guest,))
                        return self.reply(200,{"role":2},room.guest)
                if not self.role():
                    return self.reply(403,{"error":"邀請已使用或無效。"})
            role=self.role()
            if not role:
                return self.reply(403,{"error":"請使用邀請連結。"})
            if op=="quit-desktop":
                if role!=1 or not getattr(self.server,"desktop_launcher",False) or self.headers.get("Origin")!=f"http://127.0.0.1:{self.server.server_port}":
                    return self.reply(403,{"error":"限本機房主操作。"})
                try:
                    origin="http://127.0.0.1:"+str(int(os.environ.get("SEAL_LAUNCHER_PORT","18767")))
                    with urlopen(Request(origin+"/launcher/quit",data=b"",headers={"Origin":origin,"X-Seal-Launcher":"quit"}),timeout=3):
                        return self.reply(200,{})
                except OSError:
                    return self.reply(503,{"error":"無法關閉遊戲視窗。"})
            result=room.action(role,"lobby" if op=="enter" else op,data)
            if role==1 and op in ("enter","lobby"):
                result["invite"]=self.server.invite_url
                result["desktopLauncher"]=bool(getattr(self.server,"desktop_launcher",False))
                if result["desktopLauncher"]:
                    result["launcherPort"]=int(os.environ.get("SEAL_LAUNCHER_PORT","18767"))
            self.reply(200,result)
        except (ValueError,KeyError,TypeError):
            self.reply(400,{"error":"無效的連線資料。"})


class CoopServer(ThreadingHTTPServer):
    request_queue_size = 128

    def handle_error(self, request, client_address):
        import sys
        if not isinstance(sys.exc_info()[1], ConnectionError):
            super().handle_error(request, client_address)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--port",type=int,default=8778)
    parser.add_argument("--bind",default="0.0.0.0")
    parser.add_argument("--address",help="IP address friends use, including a private VPN address")
    parser.add_argument("--no-browser",action="store_true")
    parser.add_argument("--data",type=Path,default=ROOT/"build"/"coop-test")
    args=parser.parse_args()
    args.data.mkdir(parents=True,exist_ok=True)
    server=CoopServer((args.bind,args.port),partial(Handler,directory=str(ROOT/"game")))
    server.room=Room(args.data/"rewards.sqlite3")
    address=args.address or socket.gethostbyname(socket.gethostname())
    port=server.server_port
    server.invite_url=f"http://{address}:{port}/coop.html#{server.room.invite}"
    host=f"http://127.0.0.1:{port}/coop.html#{server.room.host}"
    print("1P:",host,"\n2P:",server.invite_url,flush=True)
    if not args.no_browser:
        webbrowser.open(host)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__=="__main__":
    main()
