from errno import EADDRINUSE
from functools import partial
from http.client import HTTPConnection, HTTPException
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import os
from pathlib import Path
from queue import Empty, Queue
import socket
import signal
import argparse
import subprocess
import sys
from tempfile import TemporaryFile
from threading import Lock, Thread
from urllib.parse import urlsplit
import webbrowser


HOST = "127.0.0.1"
PORT = 8767
ENTRY = "east-island-native-preview.html"
MODULE = "east-island-native-preview.mjs"


class StoryHandler(SimpleHTTPRequestHandler):
    # Windows registry MIME settings can label .mjs as text/plain, which
    # browsers reject for module scripts. Both launchers share this handler.
    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        ".mjs": "text/javascript",
        ".js": "text/javascript",
    }

    def is_source(self):
        return urlsplit(self.path).path.endswith((".html", ".mjs", ".js", ".css"))

    def do_GET(self):
        super().do_GET()
        if getattr(self.server, "report_launch", False) and self.headers.get("X-Seal-Probe") != "1":
            path = urlsplit(self.path).path
            if path in ("/" + ENTRY, "/" + MODULE):
                print("SEAL_ENTRY" if path.endswith(".html") else "SEAL_MODULE", flush=True)

    def send_head(self):
        if self.is_source() and "If-Modified-Since" in self.headers:
            del self.headers["If-Modified-Since"]
        return super().send_head()

    def end_headers(self):
        if self.is_source():
            self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_POST(self):
        coop = getattr(self.server, "desktop_coop", None)
        actions = {"/launcher/coop": "coop", "/launcher/lan": "coop", "/launcher/quit": "quit"}
        action = actions.get(self.path)
        if coop is None or action is None:
            self.send_error(404)
            return
        host = f"127.0.0.1:{self.server.server_port}"
        if (self.headers.get("Host"), self.headers.get("Origin"), self.headers.get("X-Seal-Launcher")) != (
            host, f"http://{host}", action
        ):
            self.send_error(403)
            return
        if action == "quit":
            self.send_response(204)
            self.end_headers()
            self.server.shutdown()
            return
        try:
            body = coop.open_room(self.server.server_port, self.path == "/launcher/lan").encode("utf-8")
            status = 200
        except (OSError, RuntimeError) as error:
            body = str(error).encode("utf-8")
            status = 503
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)


class DesktopCoop:
    def __init__(self, game_root):
        self.game_root = game_root.resolve()
        self.lock = Lock()
        self.process = None
        self.lobby = ""
        self.lan = None

    def open_room(self, launcher_port, lan):
        with self.lock:
            if self.process is not None and self.process.poll() is None:
                if self.lan != lan:
                    raise RuntimeError("已有另一種模式的房間。請先結束遊戲，再切換開房方式。")
                return self.lobby
            self.close_room()
            script = Path(__file__).with_name("launch-coop-remote.py")
            env = dict(os.environ, SEAL_LAUNCHER_PORT=str(launcher_port), SEAL_GAME_ROOT=str(self.game_root))
            args = [sys.executable, "-B", "-u", str(script), "--menu"]
            if lan:
                args.append("--lan")
            with TemporaryFile() as errors:
                self.process = subprocess.Popen(
                    args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors, env=env,
                    text=True, encoding="utf-8", errors="replace"
                )
                stdout = self.process.stdout
                ready = Queue()
                Thread(target=lambda: ready.put(stdout.readline().strip()), daemon=True).start()
                try:
                    lobby = ready.get(timeout=70)
                    parsed = urlsplit(lobby)
                    if parsed.scheme == "http" and parsed.hostname == "127.0.0.1" and parsed.path == "/coop.html" and parsed.fragment:
                        self.lobby, self.lan = lobby, lan
                        return lobby
                except Empty:
                    pass
                self.close_room()
                errors.seek(0)
                raise RuntimeError(errors.read().decode("utf-8", "replace").strip() or "開房逾時，請重新試一次。")

    def close_room(self):
        if self.process is None:
            return
        self.process.stdin.close()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.process.stdout.close()
        self.process = None


class StoryServer(ThreadingHTTPServer):
    # Chapter selection opens a fresh page that requests many assets in parallel.
    request_queue_size = 128

    def server_bind(self):
        if sys.platform == "win32":
            # Windows SO_REUSEADDR can bind over a running preview server.
            self.allow_reuse_address = False
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def is_story_preview(game_root, port=PORT):
    # Use a direct loopback connection and never follow redirects.
    for name in (ENTRY, MODULE):
        local = (game_root / name).read_bytes()
        conn = HTTPConnection(HOST, port, timeout=8)
        try:
            conn.request("GET", f"/{name}", headers={"Accept-Encoding": "identity", "X-Seal-Probe": "1"})
            with conn.getresponse() as response:
                if response.status != 200 or response.read(len(local) + 1) != local:
                    return False
        except (OSError, HTTPException):
            return False
        finally:
            conn.close()
    return True


def open_story(port, browser=None, desktop_coop=False):
    url = f"http://{HOST}:{port}/{ENTRY}" + ("?desktop=1" if desktop_coop else "")
    print(f"Story mode: {url}")
    try:
        if sys.platform == "darwin":
            subprocess.run(["/usr/bin/open", *(["-a", browser] if browser else []), url], check=True)
            return
        if webbrowser.open(url):
            return
    except (OSError, webbrowser.Error):
        pass
    print("Browser did not open automatically. Copy the address above into your browser.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--game-root", type=Path, default=Path(__file__).resolve().parents[1] / "game")
    parser.add_argument("--browser")
    parser.add_argument("--desktop-coop", action="store_true")
    parser.add_argument("--game-window", action="store_true")
    options = parser.parse_args()
    port = PORT
    if options.game_window:
        port = int(os.environ.get("SEAL_GAME_PORT", str(PORT)))
        if not 1 <= port <= 65535:
            parser.error("SEAL_GAME_PORT must be a valid nonzero TCP port")
    game_root = options.game_root
    for name in (ENTRY, MODULE):
        if not (game_root / name).is_file():
            raise FileNotFoundError(f"Missing game file: {game_root / name}")

    handler = partial(StoryHandler, directory=game_root)
    try:
        server = StoryServer((HOST, port), handler)
    except OSError as exc:
        if exc.errno != EADDRINUSE and getattr(exc, "winerror", None) not in (10013, 10048):
            raise
        if options.game_window:
            print("請先關閉已開啟的 SealOffline，再啟動遊戲。", file=sys.stderr)
            raise SystemExit(98) from exc
        if not options.desktop_coop and is_story_preview(game_root):
            print("Using the existing story preview server.")
            open_story(PORT, options.browser)
            return
        server = StoryServer((HOST, 0), handler)
        print(f"Port {PORT} is in use. Starting the story on another local port.")

    if options.game_window:
        def stop(_signum, _frame):
            raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, stop)

    with server:
        server.desktop_coop = DesktopCoop(game_root) if options.desktop_coop else None
        serving = Thread(target=server.serve_forever, daemon=True)
        serving.start()
        try:
            print("Keep this window open while playing. Press Ctrl+C to stop.")
            if not is_story_preview(game_root, server.server_port):
                raise OSError("遊戲入口尚未就緒，請重新啟動。")
            server.report_launch = True
            if options.game_window:
                query = "?desktop=1" if options.desktop_coop else ""
                def watch_window():
                    sys.stdin.buffer.read(1)
                    server.shutdown()
                Thread(target=watch_window, daemon=True).start()
                print(f"SEAL_GAME_URL http://{HOST}:{server.server_port}/{ENTRY}{query}", flush=True)
            else:
                print("SEAL_BROWSER", flush=True)
                open_story(server.server_port, options.browser, options.desktop_coop)
            while serving.is_alive():
                serving.join(timeout=0.5)
        except KeyboardInterrupt:
            pass
        finally:
            server.shutdown()
            if server.desktop_coop:
                with server.desktop_coop.lock:
                    server.desktop_coop.close_room()


if __name__ == "__main__":
    try:
        main()
    except OSError as exc:
        print(f"Could not start the story: {exc}", file=sys.stderr)
        sys.exit(1)
